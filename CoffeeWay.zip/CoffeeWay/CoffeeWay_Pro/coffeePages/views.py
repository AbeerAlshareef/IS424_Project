from django.shortcuts import render
from django.http import HttpResponse
from .models import Account,Coffee,Basket,Orders
# Create your views here.
def signup(request):
    if request.method == "POST":
        fullname = request.POST["fullname"]
        username = request.POST["username"]
        password = request.POST["password"]
        account = Account(
            fullname =  fullname,
            username =  username,
            password =  password
            )
        account.save()
        account = Account.objects.filter(username=username,password = password)
        request.session["a_id"] = account[0].id
        coffees = Coffee.objects.filter(money__lte=2.5)
        if coffees:
                return render(request,'homePage.html',{"coffees":coffees})
        else:
                 return render(request,'homePage.html',{"msg":"There is no offer now"})
    else:
        return render(request,'signup.html')

def homePage(request):
    coffees = Coffee.objects.filter(money__lte=10)
    if coffees:
        return render(request,'homePage.html',{"coffees":coffees})
    else:
        return render(request,'homePage.html',{"msg":"There is no offers now"})
   

def coffeePage(request):
    coffees = Coffee.objects.select_related('t_id').all()
    return render(request,'coffeePage.html',{"coffees":coffees})

def addCoffee(request):
    id = request.GET["id"]
    a_id = request.session["a_id"]
    coffee = Coffee.objects.filter(id=id)
    account = Account.objects.filter(id=a_id)
    basket = Basket(
            coff_id =  coffee[0],
            a_id =  account[0]
            )
    basket.save()
    coffees = Coffee.objects.select_related('t_id').all()
    return render(request,'coffeePage.html',{"coffees":coffees,"done":"y"})
def login(request):
    if request.method == "POST":
        username = request.POST["username"]
        password = request.POST["password"]
        account = Account.objects.filter(username=username,password = password)
        if account:
            request.session["a_id"] = account[0].id
            coffees = Coffee.objects.filter(money__lte=2.5)
            if coffees:
                return render(request,'homePage.html',{"coffees":coffees})
            else:
                 return render(request,'homePage.html',{"msg":"There is no offer now"})

        else:
            return render(request,'login.html')
    else:
        return render(request,'login.html')
def logout(request):
    del request.session["a_id"]
    return render(request,'homePage.html')


def search(request):
    coffee_name = request.GET["cname"]
    coffee = Coffee.objects.select_related('t_id').filter(coffee_name=coffee_name)
    if coffee:
        return render(request,'search.html',{"coffee":coffee[0]})
    else:
        return render(request,'search.html')
def deleteBasket(request):
    a_id = request.session["a_id"]
    Basket.objects.filter(a_id=a_id).delete()
    return render(request,'basket.html',{"deleted":"y"})

def confirmOrder(request):
    a_id = request.session["a_id"]
    account = Account.objects.filter(id=a_id)
    basket = Basket.objects.filter(a_id=a_id)
    total_money = 0
    for bask in basket:
        total_money = total_money + bask.coff_id.money
    order = Orders(
            total_money=total_money,
            a_id=account[0]
        )
    order.save()
    Basket.objects.filter(a_id=a_id).delete()
    return render(request,'basket.html',{"confirmed":"y"})
def showCoffeeData(request):
    id = request.GET["id"]
    coffee = Coffee.objects.filter(id=id)
    return render(request,'showCoffeePage.html',{"coffee":coffee[0]})

def basketPage(request):
    a_id = request.session["a_id"]
    basket = Basket.objects.select_related('coff_id').filter(a_id=a_id)
    total_money = 0
    for bask in basket:
        total_money =total_money+ bask.coff_id.money
    return render(request,'basket.html',{"basket":basket,"total_money":total_money})

def orderPage(request):
    a_id = request.session["a_id"]
    orders = Orders.objects.filter(a_id=a_id)
    return render(request,'orderPage.html',{"orders":orders})




        




