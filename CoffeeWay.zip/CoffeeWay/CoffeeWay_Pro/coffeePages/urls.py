from django.urls import path
from . import views

urlpatterns = [
    path("",views.homePage,name="homePage"),
    path("login",views.login,name="loginPage"),
    path("signup",views.signup,name="signupPage"),
    path("homePage",views.homePage,name="homePage"),
    path("coffeePage",views.coffeePage,name="coffeePage"),
    path("showCoffeeData",views.showCoffeeData,name="showCoffeeData"),
    path("basketPage",views.basketPage,name="basketPage"),
    path("orderPage",views.orderPage,name="orderPage"),
    path("logout",views.logout,name="logout"),
    path("addCoffee",views.addCoffee,name="addCoffee"),
    path("deleteBasket",views.deleteBasket,name="deleteBasket"),
    path("confirmOrder",views.confirmOrder,name="confirmOrder"),
    path("search",views.search,name="search")
]