from django.db import models

class Account(models.Model):
    id= models.AutoField(primary_key = True)
    username =  models.CharField(max_length = 50)
    password =  models.CharField(max_length = 50)
    fullname =  models.CharField(max_length = 50)
    def __str__(self):
        return f"{self.username}#{self.id} "

class CoffeeType(models.Model):
    id= models.AutoField(primary_key = True)
    type_name =  models.CharField(max_length = 50)
    def __str__(self):
        return f"{self.type_name}"
    
class Coffee(models.Model):
    id= models.AutoField(primary_key = True)
    money =  models.DecimalField(max_digits = 15,decimal_places=3)
    coffee_name =  models.CharField(max_length = 50)
    data =  models.TextField(default = "")
    t_id = models.ForeignKey(CoffeeType, null=True, on_delete=models.CASCADE)
    def __str__(self):
        return f"{self.coffee_name}"

class Basket(models.Model):
    id= models.AutoField(primary_key = True)
    coff_id = models.ForeignKey(Coffee, null=True, on_delete=models.CASCADE)
    a_id = models.ForeignKey(Account, null=True, on_delete=models.CASCADE)
    def __str__(self):
        return f"Basket #{self.id}"
    
class Orders(models.Model):
    id= models.AutoField(primary_key = True)
    total_money =  models.DecimalField(max_digits = 15,decimal_places=3)
    a_id = models.ForeignKey(Account, null=True, on_delete=models.CASCADE)
    def __str__(self):
        return f"Order #{self.id}"