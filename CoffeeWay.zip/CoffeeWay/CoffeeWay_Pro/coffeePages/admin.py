from django.contrib import admin
from .models import Coffee,Account,CoffeeType,Orders
# Register your models here.
admin.site.register(Coffee)
admin.site.register(Account)
admin.site.register(CoffeeType)
admin.site.register(Orders)
